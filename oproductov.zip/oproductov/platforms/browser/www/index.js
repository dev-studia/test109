$(document).ready(function(){
	$('.carousel.carousel-slider').carousel({fullWidth: true});
	 $(".button-collapse").sideNav();
	
	 
});