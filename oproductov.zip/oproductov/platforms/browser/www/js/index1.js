$(document).ready(function(){
	name=localStorage.getItem('user');
$(".name").append(name);
    
})